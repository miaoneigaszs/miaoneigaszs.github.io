/**
 * @file Export initWidget function to window.
 * @module waifu-tips
 */

import { initWidget } from './widget.js';

window.initWidget = initWidget;
